import { logout } from "../_lib/api.js";

export async function onRequestPost() {
  return logout();
}
