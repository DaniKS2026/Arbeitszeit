import { json } from "../_lib/api.js";
import { getSession } from "../_lib/session.js";

export async function onRequestGet({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  return json({ email: session.email, name: session.name, role: session.role });
}
