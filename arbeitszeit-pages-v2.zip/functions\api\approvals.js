import { json, listApprovals, getApproval, setApproval, deleteApproval } from "../_lib/api.js";
import { getSession } from "../_lib/session.js";

export async function onRequestGet({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  const week = new URL(request.url).searchParams.get("week");
  return week ? getApproval(env, week) : listApprovals(env);
}

export async function onRequestPut({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  if (session.role !== "admin") return json({ error: "forbidden" }, 403);
  const week = new URL(request.url).searchParams.get("week");
  if (!week) return json({ error: "missing_week" }, 400);
  return setApproval(request, env, week, session);
}

export async function onRequestDelete({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  if (session.role !== "admin") return json({ error: "forbidden" }, 403);
  const week = new URL(request.url).searchParams.get("week");
  if (!week) return json({ error: "missing_week" }, 400);
  return deleteApproval(env, week);
}
