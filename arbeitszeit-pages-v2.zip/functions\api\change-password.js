import { json, changePassword } from "../_lib/api.js";
import { getSession } from "../_lib/session.js";

export async function onRequestPost({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  return changePassword(request, env, session);
}
