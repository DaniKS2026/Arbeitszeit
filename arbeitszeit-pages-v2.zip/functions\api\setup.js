import { setupUser } from "../_lib/api.js";

export async function onRequestPost({ request, env }) {
  return setupUser(request, env);
}
