import { json, getAbsence, setAbsence } from "../_lib/api.js";
import { getSession } from "../_lib/session.js";

export async function onRequestGet({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  return getAbsence(env);
}

export async function onRequestPut({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  if (session.role !== "admin") return json({ error: "forbidden" }, 403);
  return setAbsence(request, env, session);
}
