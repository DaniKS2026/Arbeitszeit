import { login } from "../_lib/api.js";

export async function onRequestPost({ request, env }) {
  return login(request, env);
}
