import { readCookie, verifySession } from "./auth.js";

export async function getSession(request, env) {
  const token = readCookie(request, "session");
  if (!token) return null;
  return await verifySession(token, env.SESSION_SECRET);
}
