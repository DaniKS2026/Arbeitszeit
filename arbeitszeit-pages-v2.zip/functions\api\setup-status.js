import { setupStatus } from "../_lib/api.js";

export async function onRequestGet({ env }) {
  return setupStatus(env);
}
