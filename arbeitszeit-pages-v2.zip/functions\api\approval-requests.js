import { json, listApprovalRequests, getApprovalRequest, setApprovalRequest, deleteApprovalRequest } from "../_lib/api.js";
import { getSession } from "../_lib/session.js";

export async function onRequestGet({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  const week = new URL(request.url).searchParams.get("week");
  return week ? getApprovalRequest(env, week) : listApprovalRequests(env);
}

export async function onRequestPut({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  const week = new URL(request.url).searchParams.get("week");
  if (!week) return json({ error: "missing_week" }, 400);
  return setApprovalRequest(request, env, week, session);
}

export async function onRequestDelete({ request, env }) {
  const session = await getSession(request, env);
  if (!session) return json({ error: "unauthorized" }, 401);
  const week = new URL(request.url).searchParams.get("week");
  if (!week) return json({ error: "missing_week" }, 400);
  return deleteApprovalRequest(env, week);
}
